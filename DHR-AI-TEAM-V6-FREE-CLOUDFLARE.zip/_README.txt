DHR AI TEAM V6 - FREE CLOUDFLARE PACKAGE
Main Managers: Sonam Rinchen + Dechan - Full Access
WhatsApp: +61 0452 337 260 (single number, private)
Features: Right menu collapsible, Operations/Live Agents hideable, All tabs working, Autonomous LIVE internet

DEPLOY FREE (no charge ever):
1. Go to pages.cloudflare.com -> Create Project -> Direct Upload
2. Drag the whole folder or zip - upload
3. Get free link dhr-ai-team.pages.dev - 100% free forever

Offline: Open index.html directly on phone Files app - works without internet
